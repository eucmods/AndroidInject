#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include "FloaterManager/Unity/Vector2.h"
#include "FloaterManager/Unity/Vector3.h"
#include "FloaterManager/Unity/Color.h"
#include "FloaterManager/Unity/Quaternion.h"
#include "FloaterManager/Manager/ESP.h"


extern "C"
JNIEXPORT void JNICALL
Java_com_mycompany_iamcmods_FloatingMenuService_GetOptions(JNIEnv *env, jclass clazz,jint feature, jboolean is_true) {
    switch (feature) {
        case 1:
            Bools_t::isESP = is_true;
            break;
        case 2:
            Bools_t::isPlayerLine = is_true;
            break;
        case 3:
            Bools_t::isPlayerBox = is_true;
            break;
        case 4:
			Bools_t::isESPHealth = is_true;
			break;
		case 5:
			Bools_t::isMira = is_true;
			break;
    }
}




int Extrasensory_Perception(JNIEnv *env) {
    JNINativeMethod methods[] = {{"native_onDraw",  "(Landroid/graphics/Canvas;IIF)V",(void *) native_onDraw}};
    jclass clazz = env->FindClass("com/mycompany/iamcmods/NativeCanvas");
    if (!clazz)
        return -1;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return -1;
    return 0;
}
JNIEXPORT jint JNICALL 
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
	if (Extrasensory_Perception(env) != 0)
    return -1;
    return JNI_VERSION_1_6;
}
