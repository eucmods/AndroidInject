package com.mycompany.iamcmods;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.app.Activity;
import android.widget.Toast;
import android.widget.TextView;
import android.content.Intent;
import android.os.Handler;
import android.widget.LinearLayout;
import android.util.Log;
import android.os.Build;
import android.content.DialogInterface;
import android.provider.Settings;
import android.net.Uri;
import android.annotation.Nullable;
import android.app.AlertDialog;

public class MainActivity extends Activity {
	
    private Button swiperButton;
    private ProgressBar progressBar;
    private float initialX;
    private boolean isSwiped = false;
	public TextView logTextView;
	private LinearLayout linearinject;
	private static int REQUEST_OVERLAY = 2929;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		requestOverlayPermission();
        swiperButton = findViewById(R.id.swiperButton);
        progressBar = findViewById(R.id.progressBar);
		linearinject = findViewById(R.id.linearinject);
		logTextView = findViewById(R.id.logTextView);
		// Exemplo de uso: adicionar logs ao TextView
        addLog("Console :");
		swiperButton.setOnTouchListener(new View.OnTouchListener() {
		 @Override
		public boolean onTouch(View v, MotionEvent event) {
		switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				// Salvar a posição X inicial quando o botão é pressionado
				initialX = event.getX();
				return true;
			case MotionEvent.ACTION_MOVE:
				// Calcular a diferença entre a posição X atual e a posição X inicial
				float diffX = event.getX() - initialX;
				// Verificar se o botão foi deslizado para a direita (positivo) ou para a esquerda (negativo)
				if (diffX > 0) {
					// Botão deslizado para a direita
					swiperButton.setTranslationX(diffX);
					//swipeButton();
				} else {
					// Botão deslizado para a esquerda
					swiperButton.setTranslationX(0);
				}
				return true;
			case MotionEvent.ACTION_UP:
				// Verificar se o botão foi deslizado até a metade da largura
				if (Math.abs(swiperButton.getTranslationX()) >= swiperButton.getWidth() / 2) {
					// Botão deslizado até a metade ou mais da largura (considerado como "deslizado")
					// Lógica a ser executada quando o botão for deslizado, por exemplo, executar uma ação
					swipeButton();
					addLog("lib uploaded...");
					Toast.makeText(getApplicationContext(), "Inject Deslizado", Toast.LENGTH_SHORT).show();
					swiperButton.setVisibility(View.GONE);
					linearinject.setVisibility(View.GONE);
					Handler handler = new Handler();
					handler.postDelayed(new Runnable() {
							@Override
							public void run() {
							//COLOQUE UM CÓDIGO PARA MOVER O ARQUIVO DA ASSETS (DEAMON) , PARA ALGUM LOCAL DA MEMORIA
							
							
								addLog("lib uploaded successfully");
								progressBar.setVisibility(View.INVISIBLE);
							}
						}, 20000); // 20 segundos em milissegundos
				}
				// Restaurar a posição original do botão
				swiperButton.setTranslationX(0);
				resetButton();
				return true;
		}
		return false;
	}
	});
}
	public void OnStart(View v){
		addLog("Startup Menu");
		startService(new Intent(this, Overlay.class));
        startService(new Intent(this, FloatingMenuService.class));
	}
	public void OnStop(View v){
		addLog("onStop Menu");
		stopService(new Intent(this, Overlay.class));
        stopService(new Intent(this, FloatingMenuService.class));
	}

    private void swipeButton() {
        swiperButton.animate()
			.translationXBy(swiperButton.getWidth())
			.setDuration(300)
			.setListener(new AnimatorListenerAdapter() {
				@Override
				public void onAnimationEnd(Animator animator) {
					progressBar.setVisibility(View.VISIBLE);
					simulateProgress();
				}
			})
			.start();
        isSwiped = true;
    }
    private void resetButton() {
        if (isSwiped) {
            swiperButton.animate()
			.translationX(0)
			.setDuration(300)
			.setListener(null)
			.start();
            //progressBar.setVisibility(View.INVISIBLE);
            isSwiped = false;
        }
    }
    private void simulateProgress() {
        progressBar.setProgress(0);
        progressBar.setMax(100);
        Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						for (int progress = 0; progress <= 100; progress++) {
							Thread.sleep(50);
							progressBar.setProgress(progress);
						}
					} catch (InterruptedException e) {
						addLog("Interrupted ProgressBar " + e);
						e.printStackTrace();
					}
				}
			});

        thread.start();
    }
	private void requestOverlayPermission(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)){
				new AlertDialog.Builder(this)
					.setMessage("This application requires overlay permission please permission first")
					.setCancelable(false)
					.setPositiveButton("OK", new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialog, int i) {
							Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
							startActivityForResult(intent, REQUEST_OVERLAY);
						}
					})
					.show();
            }
        }
    }
	@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestOverlayPermission();
            }
        }
    }
	private void addLog(String log) {
        Log.d("Console", log); // Opcional: exibir log no Logcat
        String currentLogs = logTextView.getText().toString();
        String newLogs = currentLogs + log + "\n";
        logTextView.setText(newLogs);
    }
}
