package com.mycompany.iamcmods.instagram;

import android.graphics.Canvas;
import java.util.Random;
import android.view.WindowManager;
import android.graphics.Color;
import com.mycompany.iamcmods.FloatingMenuService;
import android.graphics.Paint;

public class lineAi {
	
	public static float lineWidth = 3.50f;
	public static int alpha = 255;

    public static void Ponteiro_Draw(Canvas canvas){
		// Gerar valores de cor RGB aleatórios
		Random random = new Random();
		int red = random.nextInt(256);
		int green = random.nextInt(256);
		int blue = random.nextInt(256);
		float a2 = (float) (FloatingMenuService.paramsMenu.x/*+ a(190)*/);
		float f2 = (float) FloatingMenuService.paramsMenu.y;
		WindowManager.LayoutParams layoutParams = FloatingMenuService.paramsIcon;
		int GerarColors = Color.rgb(red, green, blue);
		//Toast.makeText(getApplicationContext(),"Generated Color: " + GerarColors,Toast.LENGTH_SHORT).show();
		DrawLine(canvas, alpha, GerarColors, lineWidth, a2, f2, (float) layoutParams.x, (float) layoutParams.y);
	}

	public static void DrawLine(Canvas cvs, int a, int GerarColors, float lineWidth, float fromX, float fromY, float toX, float toY) {
        Paint mStrokePaint = new Paint();
		mStrokePaint.setColor(GerarColors);
        mStrokePaint.setAlpha(a);
        mStrokePaint.setStrokeWidth(lineWidth);
        cvs.drawLine(fromX, fromY, toX, toY, mStrokePaint);
    }
	
}
