#ifndef OFFSETS_H
#define OFFSETS_H

namespace Offsets {
/*
    RADDR Crosshair = 0x136DAB0;
    RADDR Recoil = 0x136D4F8;
    RADDR Character = 0x381FCB0;
    RADDR Aimbot = 0x258B740;
*/
}

#endif