#ifndef CMODS_H
#define CMODS_H


#include "CM/Log.h"
#include "CM/MemoryPatch.h"


MemoryPatch Mem;



#endif
