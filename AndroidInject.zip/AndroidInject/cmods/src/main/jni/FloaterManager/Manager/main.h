#ifndef MAIN_H
#define MAIN_H

#include <cstdio>
#include <cstdlib>
#include <cstddef>
#include <dirent.h>
#include <unistd.h>
#include <cmath>
#include <ctime>
#include <string>
#include <vector>
#include <list>
#include <stack>
#include <iostream>
#include <iomanip>
#include <fstream>

//#include "Log.h"
/*
#include "Process.h"
#include "Memory.h"
*/
static const char* game_version = "1.99.0";
static const char* process_name = "com.dts.freefireth";
static const char* lib_name = "libil2cpp.so";

int Width;
int Height;

#endif
