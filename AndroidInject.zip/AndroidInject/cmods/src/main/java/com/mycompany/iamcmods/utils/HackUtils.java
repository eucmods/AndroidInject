package com.mycompany.iamcmods.utils;

import android.util.Log;
import android.content.Context;

public class HackUtils {

	//-----CPP ON<OFF
	public static int ESP = 1;
	public static int isPlayerLine = 2;
	public static int isPlayerBox = 3;
	public static int isESPHealth = 4;
	public static int isMira = 5;
}

