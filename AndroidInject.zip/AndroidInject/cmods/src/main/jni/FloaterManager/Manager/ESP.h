#ifndef ESP_H
#define ESP_H
#include "Engine/Canvas.h"
#include "bools.h"
#include "main.h"


namespace ESP_t{
	static Canvas *m_Canvas = nullptr;
}

namespace EnemyList{
	
}

void DrawCrosshair(int screenWidth, int screenHeight,float size = 20) {
	  Vector2 center = Vector2(screenWidth / 2, screenHeight / 2);
      float x = center.X - (size / 2.0f);
      float y = center.Y- (size / 2.0f);
	  ESP_t::m_Canvas->drawLine(x, center.Y, x + size,center.Y, 3, RED);
	  ESP_t::m_Canvas->drawLine(center.X, y, center.X, y+ size, 3, RED);
}
void native_onDraw(JNIEnv *env, jclass clazz, jobject canvas, int screenWidth, int screenHeight, float screenDensity) {
     if (!ESP_t::m_Canvas){
	    ESP_t::m_Canvas = new Canvas(env, screenWidth, screenHeight, screenDensity);
	}
    if (!ESP_t::m_Canvas)
	return;
    ESP_t::m_Canvas->UpdateCanvas(canvas);
	if(Bools_t::isMira){
	DrawCrosshair(screenWidth,screenHeight,42);
	}
}
//Bools_t::m_Canvas->drawText(buffer,screenWidth - (screenWidth - BoxPosNew.X), (screenHeight - BoxPosNew.Y + 12.0f));

#endif
