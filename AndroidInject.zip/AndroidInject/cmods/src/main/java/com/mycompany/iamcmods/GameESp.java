package com.mycompany.iamcmods;

import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.util.DisplayMetrics;
import com.mycompany.iamcmods.instagram.lineAi;
import android.util.Log;
import com.mycompany.iamcmods.FloatingMenuService;
import android.view.WindowManager;
import android.view.Gravity;

public class GameESp extends View {
	
	int screenWidth, screenHeight, screenDpi;
	static long sleepTime = 4000 / 60;
	
	public GameESp(Context context) {
		super(context);
		UpdateCanvas.start();
	}
	@Override
	protected void onDraw(Canvas canvas) {
		try {
			DisplayMetrics metrics = getResources().getDisplayMetrics();
			screenWidth = canvas.getWidth();//WIDTH CANVAS
			screenHeight = canvas.getHeight();//HEIGHT CANVAS
			float screenDensity = metrics.density;
			NativeCanvas.native_onDraw(canvas, screenWidth, screenHeight, screenDensity);
			lineAi.Ponteiro_Draw(canvas);
			//CrossHair.drawCrosshair(canvas);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	Thread UpdateCanvas = new Thread() {
		@Override
		public void run() {
			android.os.Process.setThreadPriority(10);
			while (isAlive() && !isInterrupted()) {
				try {
					long currentTimeMillis = System.currentTimeMillis();
					postInvalidate();
					Thread.sleep(Math.max(Math.min(0, sleepTime - (System.currentTimeMillis() - currentTimeMillis)), sleepTime));
				} catch (Exception e) {
					Log.e("OverlayThread", e.getMessage());
				}
			}
		}
	};
}
