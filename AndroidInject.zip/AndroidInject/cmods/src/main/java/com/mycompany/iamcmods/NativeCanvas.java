package com.mycompany.iamcmods;

import android.graphics.Canvas;

public class NativeCanvas {
    static {
        System.loadLibrary("pid");
    }
   public static native void native_onDraw(Canvas canvas, int screenWidth, int screenHeight, float screenDensity);

}
