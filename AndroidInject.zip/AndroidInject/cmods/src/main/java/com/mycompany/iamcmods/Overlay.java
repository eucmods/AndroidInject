package com.mycompany.iamcmods;

import android.annotation.*;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import java.io.*;
import java.lang.Process;
import android.widget.Toast;
import com.mycompany.iamcmods.NativeCanvas;
import com.mycompany.iamcmods.instagram.parametros;

public class Overlay extends Service {
	
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    WindowManager windowManager;
    Process process;
	int screenWidth, screenHeight;
    View mainView;
    private GameESp CLarguras;
    @SuppressLint("StaticFieldLeak")
    private static Overlay Instance;
    static Context ctx;

    @SuppressLint("InflateParams")
    @Override
    public void onCreate() {
        super.onCreate();
        ctx = this;
        windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        try {
			CLarguras = new GameESp(this);
		} catch (Exception e) {
			Toast.makeText(this, e.toString(), 1).show();
		}
		DrawCanvas();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (CLarguras != null) {
            ((WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE)).removeView(CLarguras);
            CLarguras = null;
        }
        if (process != null)
            process.destroy();
    }


    public static void Stop(Context context) {
        Intent intent = new Intent(context, Overlay.class);
        context.stopService(intent);
        Intent floatLogo = new Intent(context, FloatingMenuService.class);
        context.stopService(floatLogo);
    }

    private void DrawCanvas() {
		WindowManager.LayoutParams layoutParamsx = new WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, 56 | WindowManager.LayoutParams.FLAG_FULLSCREEN, -3);
		layoutParamsx.gravity = Gravity.CENTER; 
		layoutParamsx.x = 0; 
		layoutParamsx.y = 0;
		windowManager.addView(CLarguras, layoutParamsx);//////END ESPVIEW
    }

    public void Shell(String str) {
        DataOutputStream dataOutputStream = null;
        try {
            process = Runtime.getRuntime().exec(str);
        } catch (IOException e) {
            e.printStackTrace();
            process = null;
        }
        if (process != null) {
            dataOutputStream = new DataOutputStream(process.getOutputStream());
        }
        try {
            if (dataOutputStream != null)
                dataOutputStream.flush();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        try {
            if (process != null)
                process.waitFor();
        } catch (InterruptedException e3) {
            e3.printStackTrace();
        }
    }

}
