#ifndef BOOLS_H
#define BOOLS_H

namespace Bools_t{
    bool isESP, isPlayerLine, isPlayerBox,isESPHealth,isMira;
	int CrossSize = 40;
	Color color = Color::White();
	float angle = 1;
	float Width_ESP = 1.5f;
	int Color_INT = RED;//0xffffffff;
	float YAxis = 1;
}

#endif
