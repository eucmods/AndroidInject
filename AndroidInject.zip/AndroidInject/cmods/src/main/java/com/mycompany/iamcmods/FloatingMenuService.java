package com.mycompany.iamcmods;

import android.view.WindowManager;
import android.app.Service;
import android.view.View;
import android.widget.LinearLayout;
import android.content.Intent;
import android.os.IBinder;
import android.widget.ImageView;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.widget.Button;
import android.graphics.Color;
import android.view.ViewGroup;
import android.view.MotionEvent;
import android.util.AttributeSet;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.content.res.Configuration;
import android.annotation.Nullable;
import android.util.Log;
import java.util.Date;
import android.os.AsyncTask;
import java.io.IOException;
import java.net.InetAddress;
import android.icu.text.SimpleDateFormat;
import android.graphics.PorterDuff;
import java.util.Locale;
import android.content.ComponentCallbacks2;
import android.view.WindowManager.LayoutParams;
import android.widget.Switch;
import android.annotation.SuppressLint;
import android.os.Handler;
import android.widget.Toast;
import android.widget.CheckBox;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.ScrollView;
import android.widget.RelativeLayout;
import android.widget.CompoundButton;
import android.graphics.drawable.GradientDrawable;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import com.mycompany.iamcmods.utils.HackUtils;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.graphics.drawable.BitmapDrawable;
import android.widget.TextView;
import android.graphics.Typeface;
import java.util.Random;
import com.mycompany.iamcmods.instagram.iconView;
import android.text.Html;
import android.os.Build;
import com.mycompany.iamcmods.instagram.boyView;
import com.mycompany.iamcmods.NativeCanvas;
import com.mycompany.iamcmods.instagram.lineAi;
import android.content.res.ColorStateList;
import java.io.IOException;
import android.content.res.AssetManager;
import java.io.InputStream;
import android.graphics.drawable.Drawable;
//import com.mycompany.cmods.instagram.parametros;
import java.net.InetAddress;
import java.net.UnknownHostException;
import android.app.ActivityManager;


public class FloatingMenuService extends Service implements View.OnTouchListener {
   static{
		System.loadLibrary("pid");
	}
    private WindowManager windowManager;
    private View floatingIcon;
    private LinearLayout menuLayout;
    private boolean isMenuOpen = false;

    public static WindowManager.LayoutParams paramsIcon;
    public static WindowManager.LayoutParams paramsMenu;
    private float DADOS_SALVAR;
    private int initialX,initialY;
    private float initialTouchX,initialTouchY;
    //protected Context context;
    GameESp CLarguras;

	private LinearLayout Vizuali,caixadebotoes,caixadebotoes2,caixadebotoes3,tab_inject;
	private RelativeLayout collapse_view;

	private LinearLayout linearLayoutPrincipal,linearLayoutTab;

	private ScrollView scrollView;

	private LinearLayout DESLIZE_caixadebotoes2,DESLIZE_caixadebotoes;
	String result;
	private int counter = 0;
    private Handler handler;
    private Runnable runnable;
	
	public String meu_icone = iconView.EncImage;
	
	private interface SW {
        void OnWrite(boolean z);
    }
	static private void setImageFromAssets(ImageView image,String name,Context ct){
        AssetManager assetManager=ct.getAssets();
        try{
            InputStream inputStream = assetManager.open(name);
            image.setImageDrawable(Drawable.createFromStream(inputStream,null));
        } catch (IOException e){
            Toast.makeText(ct,"Error could not load image from assets folder \n"+e.getMessage(),Toast.LENGTH_SHORT).show();
        }
	}  
	
	//********** ESP DRAW ***********//
	public static native void GetOptions(int feature, boolean about);
	//**************//
	
	@Override
    public IBinder onBind(Intent intent) {
        return null;
    }
	@Override
    public void onCreate() {
        super.onCreate();
        CriarLayout();
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        // Configure the window layout parameters for the floating icon
        paramsIcon = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        paramsIcon.gravity = Gravity.TOP | Gravity.START;
        paramsIcon.x = paramsIcon.x - collapse_view.getWidth();//0;
        paramsIcon.y = paramsIcon.y - collapse_view.getWidth();//100;
		paramsIcon.setColorMode(Color.parseColor("#FF313131"));
        windowManager.addView(collapse_view, paramsIcon);
	}
    @SuppressLint("NewApi")
    private void CriarLayout() {
        // Configure the floating icon layout
		collapse_view = new RelativeLayout(this);
		RelativeLayout.LayoutParams relativeLayoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        collapse_view.setLayoutParams(relativeLayoutParams);
		collapse_view.setOnTouchListener(this);
		collapse_view.setBackgroundColor(Color.parseColor("#FF313131"));
		
        floatingIcon = new ImageView(this);
		LinearLayout.LayoutParams collapsed_ivparams = new LinearLayout.LayoutParams(dp(55), dp(55));
		byte[] imageBytes_1 = Base64.decode(meu_icone, 0);
		((ImageView) floatingIcon).setImageBitmap(BitmapFactory.decodeByteArray(imageBytes_1, 0, imageBytes_1.length));
		floatingIcon.setLayoutParams(collapsed_ivparams);
		collapse_view.addView(floatingIcon);
		
        // Configure the menu layout
        menuLayout = new LinearLayout(this);
        menuLayout.setBackgroundColor(Color.WHITE);
		LinearLayout.LayoutParams expanded_containerParams = new LinearLayout.LayoutParams(dp(260), -2);
		menuLayout.setLayoutParams(expanded_containerParams);
        menuLayout.setOrientation(LinearLayout.VERTICAL);
        menuLayout.setGravity(Gravity.CENTER);
		menuLayout.setBackgroundColor(-16777216);
		menuLayout.setAlpha(0.8f);
	
		addAll("Team", new View.OnClickListener() {
			boolean settingsOpen;
                @Override
                public void onClick(View v) {
                    try {
						settingsOpen = !settingsOpen;
						if (settingsOpen) {
							tab_inject.setVisibility(View.VISIBLE);
							Vizuali.removeView(caixadebotoes);
							Vizuali.removeView(caixadebotoes2);
							Vizuali.removeView(caixadebotoes3);
							Vizuali.addView(tab_inject);
							Vizuali.scrollTo(0, 0);
						} else {
							tab_inject.setVisibility(View.GONE);
							stopUpdatingText();
							Vizuali.removeView(tab_inject);
							Vizuali.addView(caixadebotoes);
							Vizuali.addView(caixadebotoes2);
							Vizuali.addView(caixadebotoes3);
						}
					} catch (IllegalStateException e) {
					}
                }
          });
		 
		LinearLayout BCT = new LinearLayout(this);
		BCT.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        BCT.setOrientation(LinearLayout.HORIZONTAL);
		  
		linearLayoutTab = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParamsLinearLayoutTab = new LinearLayout.LayoutParams(dp(45), -2);
        layoutParamsLinearLayoutTab.topMargin = dp(3);
		linearLayoutTab.setLayoutParams(layoutParamsLinearLayoutTab);
		linearLayoutTab.setOrientation(LinearLayout.VERTICAL);
        linearLayoutTab.setBackgroundColor(Color.parseColor("#FFFFFF"));
		
		final LinearLayout Linx1 = new LinearLayout(this);
		Linx1.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(35)));
		Linx1.setGravity(17);
		ImageView  I1 = new ImageView(this);
		I1.setScaleType(ImageView.ScaleType.FIT_CENTER);
        setImageFromAssets(I1,"back/Esp.png",this);
		I1.setColorFilter(Color.BLACK);
		I1.setLayoutParams(new LinearLayout.LayoutParams(dp(27),dp(27)));
		
		final LinearLayout Linx2 = new LinearLayout(this);
		Linx2.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(35)));
		Linx2.setGravity(17);
		ImageView  L2 = new ImageView(this);
		L2.setScaleType(ImageView.ScaleType.FIT_CENTER);
        setImageFromAssets(L2,"back/Aim.png",this);
		L2.setColorFilter(Color.BLACK);
		L2.setLayoutParams(new LinearLayout.LayoutParams(dp(27),dp(27)));

		final LinearLayout Linx3 = new LinearLayout(this);
		Linx3.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(35)));
		Linx3.setBackgroundColor(Color.DKGRAY);
		Linx3.setGravity(17);
		ImageView  L3 = new ImageView(this);
		L3.setScaleType(ImageView.ScaleType.FIT_CENTER);
        setImageFromAssets(L3,"back/Other.png",this);
		L3.setColorFilter(Color.BLACK);
		L3.setLayoutParams(new LinearLayout.LayoutParams(dp(27),dp(27)));
		Linx1.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Linx1.setBackgroundColor(Color.DKGRAY);
					Linx2.setBackgroundColor(0);
					Linx3.setBackgroundColor(0);
					caixadebotoes.setVisibility(View.GONE);
					caixadebotoes3.setVisibility(View.VISIBLE);
					caixadebotoes2.setVisibility(View.GONE);
                }
            });
		Linx2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Linx1.setBackgroundColor(0);
					Linx2.setBackgroundColor(Color.DKGRAY);
					Linx3.setBackgroundColor(0);
					caixadebotoes2.setVisibility(View.GONE);
					caixadebotoes3.setVisibility(View.GONE);
					caixadebotoes.setVisibility(View.VISIBLE);
                }
            });
		Linx3.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Linx1.setBackgroundColor(0);
					Linx2.setBackgroundColor(0);
					Linx3.setBackgroundColor(Color.DKGRAY);
					caixadebotoes.setVisibility(View.GONE);
					caixadebotoes3.setVisibility(View.GONE);
					caixadebotoes2.setVisibility(View.VISIBLE);
                }
            });
		linearLayoutTab.addView(Linx1);
		Linx1.addView(I1);
		linearLayoutTab.addView(Linx2);
		Linx2.addView(L2);
		linearLayoutTab.addView(Linx3);
		Linx3.addView(L3);
		
		linearLayoutPrincipal = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParamsLinearLayoutPrincipal = new LinearLayout.LayoutParams(dp(270), -2);
        layoutParamsLinearLayoutPrincipal.topMargin = dp(3);
		linearLayoutPrincipal.setLayoutParams(layoutParamsLinearLayoutPrincipal);
		linearLayoutPrincipal.setAlpha(0.8f);
		linearLayoutPrincipal.setOrientation(LinearLayout.VERTICAL);
        linearLayoutPrincipal.setPadding(0, 0/*16*/, 0, 16);
		
		scrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollView_Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, -2);//dp(200));
        scrollView.setLayoutParams(scrollView_Params);
		
		Vizuali = new LinearLayout(this);
        LinearLayout.LayoutParams linearLayout__Vizuali = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        Vizuali.setLayoutParams(linearLayout__Vizuali);
        Vizuali.setOrientation(LinearLayout.VERTICAL);
		
		caixadebotoes = new LinearLayout(this);
        LinearLayout.LayoutParams linearLayout__com_botoes_Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        caixadebotoes.setLayoutParams(linearLayout__com_botoes_Params);
        caixadebotoes.setOrientation(LinearLayout.VERTICAL);
		caixadebotoes.setVisibility(View.GONE);
		//scrollView.addView(caixadebotoes);
		
		caixadebotoes2 = new LinearLayout(this);//Menu LOGS CONSOLE
        LinearLayout.LayoutParams linearLayout__com_botoes_Params2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        caixadebotoes2.setLayoutParams(linearLayout__com_botoes_Params2);
        caixadebotoes2.setOrientation(LinearLayout.VERTICAL);
		caixadebotoes2.setVisibility(View.VISIBLE);
		
		caixadebotoes3 = new LinearLayout(this);
        LinearLayout.LayoutParams linearLayout__com_botoes_Params3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        caixadebotoes3.setLayoutParams(linearLayout__com_botoes_Params3);
        caixadebotoes3.setOrientation(LinearLayout.VERTICAL);
		caixadebotoes3.setVisibility(View.GONE);
		
		tab_inject = new LinearLayout(this);
        LinearLayout.LayoutParams linearLayout__tab_inject = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        tab_inject.setLayoutParams(linearLayout__tab_inject);
        tab_inject.setOrientation(LinearLayout.VERTICAL);
		tab_inject.setVisibility(View.GONE);
		
		LinearLayout view1 = new LinearLayout(this);
		view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 3));
        view1.setBackgroundColor(Color.parseColor("#FFFFFF"));
		menuLayout.addView(view1);
		
        // Configure the menu buttons
		Barracima();
		List_Menu2_View();
		List_Menu_ESP_View();
		List_Menu_FUNC_View();
		Vizuali.addView(caixadebotoes2);
		Vizuali.addView(caixadebotoes);
		Vizuali.addView(caixadebotoes3);
		Vizuali.addView(tab_inject);
		scrollView.addView(Vizuali);
		
		linearLayoutPrincipal.addView(scrollView);
		BCT.addView(linearLayoutTab);
		BCT.addView(linearLayoutPrincipal);
		menuLayout.addView(BCT);
    }
	void Barracima(){
		addMenuSwiperButton(">>>>", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ///closeMenu();
                }
            });
	}
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                initialX = paramsIcon.x;
                initialY = paramsIcon.y;
                initialTouchX = event.getRawX();
                initialTouchY = event.getRawY();
                return true;
            case MotionEvent.ACTION_MOVE:
                int xDiff = (int) (event.getRawX() - initialTouchX);
                int yDiff = (int) (event.getRawY() - initialTouchY);
                paramsIcon.x = initialX + xDiff;
                paramsIcon.y = initialY + yDiff;
                windowManager.updateViewLayout(collapse_view, paramsIcon);
                return true;
            case MotionEvent.ACTION_UP:
                if (Math.abs(event.getRawX() - initialTouchX) < 10 && Math.abs(event.getRawY() - initialTouchY) < 10) {
                    if (isMenuOpen) {
                        closeMenu();
                    } else {
                        openMenu();
                    }
                }
                return true;
        }
        return false;
    }
	void List_Menu2_View(){
		Category("</b><font color='#00F6500'><b>" + Build.TAGS + "</font></b><font color='#00FF00'> : <b>" + Build.SERIAL + "</font>");
		Category("</b><font color='#0c6eff'><b>" + "Criador Por CMODs" + "</font>");
	}
	void List_Menu_ESP_View(){
		addCheckBox("ESP", new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					GetOptions(HackUtils.ESP, isChecked);
                }
            });
        addCheckBox("ESP - LINE", new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					GetOptions(HackUtils.isPlayerLine, isChecked);
                }
            });
        addCheckBox("ESP - BOX", new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					GetOptions(HackUtils.isPlayerBox, isChecked);
                }
            });
		addCheckBox("ESP - Health", new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					GetOptions(HackUtils.isESPHealth, isChecked);
                }
            });
		addCheckBox("ESP - CrossHair", new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					GetOptions(HackUtils.isMira, isChecked);
                }
            });
		}
		
	void List_Menu_FUNC_View(){
		addCheckBox_fuc("HS", new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					//GetOptions(HackUtils.HS, isChecked);
                }
            });
        addCheckBox_fuc("WALL STONE", new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					//GetOptions(HackUtils.WALLSTONE, isChecked);
                }
            });
		}
		
	private void addMenuSwiperButton(String buttonText, View.OnClickListener clickListener) {
		final LinearLayout head = new LinearLayout(this);
		head.setOrientation(LinearLayout.HORIZONTAL);
		head.setGravity(Gravity.CENTER);
		head.setBackgroundColor(Color.DKGRAY);
		
		RelativeLayout titleText = new RelativeLayout(this);
		titleText.setPadding(10, 5, 10, 5);
		titleText.setVerticalGravity(16);

		LayoutParams headparams = new LayoutParams(-1, dp(39));
		headparams.height = dp(39);
		head.setPadding(dp(5), 0, 5, 0);
		head.setLayoutParams(headparams);

		final TextView headText = new TextView(this);
		RelativeLayout.LayoutParams cmodsL = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
		cmodsL.addRule(RelativeLayout.CENTER_VERTICAL);
		headText.setLayoutParams(cmodsL);
		headText.setText(buttonText);
		headText.setTextSize(13f);
		headText.setTextColor(Color.WHITE);

		final ImageView arrow = new ImageView(this);
		RelativeLayout.LayoutParams rlsettings = new RelativeLayout.LayoutParams(dp(35), dp(35));
		rlsettings.rightMargin = Gravity.RIGHT;
		rlsettings.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
		arrow.setLayoutParams(rlsettings);
		
		arrow.setScaleType(ImageView.ScaleType.FIT_CENTER);
        setImageFromAssets(arrow,"back/inject.png",this);
		//arrow.setRotation(180);
		arrow.setColorFilter(Color.parseColor("#FFFF0000"), PorterDuff.Mode.MULTIPLY);

		titleText.addView(headText);
		titleText.addView(arrow);
		head.addView(titleText);
		
		final TextView textView = new TextView(this);
		LinearLayout.LayoutParams bct22 = new LinearLayout.LayoutParams(MATCH_PARENT, dp(25));
		textView.setLayoutParams(bct22);
		textView.setPadding(dp(6),dp(4),dp(3),dp(3));
		textView.setBackgroundColor(Color.parseColor("#000000"));
		textView.setText(Html.fromHtml("</b><font color='#00F6500'><b>Inject</font></b><font color='red'> : <b>Offline</font>"));
		//textView.setGravity(Gravity.CENTER);
		textView.setTextColor(Color.parseColor("#FFFFFF"));
		textView.setTypeface(null, Typeface.BOLD);
		
		final TextView LOGS_ONO_OFF = new TextView(this);
		LinearLayout.LayoutParams bct22Logs = new LinearLayout.LayoutParams(MATCH_PARENT, dp(25));
		LOGS_ONO_OFF.setLayoutParams(bct22Logs);
		LOGS_ONO_OFF.setPadding(dp(6),dp(4),dp(3),dp(3));
		LOGS_ONO_OFF.setBackgroundColor(Color.parseColor("#000000"));
		LOGS_ONO_OFF.setText("Console : logs");
		LOGS_ONO_OFF.setGravity(Gravity.CENTER);
		LOGS_ONO_OFF.setTextColor(Color.parseColor("#FFFFFF"));
		LOGS_ONO_OFF.setTypeface(null, Typeface.BOLD);
		
        head.setOnClickListener(clickListener);
		head.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							// Salvar a posição X inicial quando o botão é pressionado
							DADOS_SALVAR = event.getX();
							return true;
						case MotionEvent.ACTION_MOVE:
							// Calcular a diferença entre a posição X atual e a posição X inicial
							float diffX = event.getX() - initialX;
							// Verificar se o botão foi deslizado para a direita (positivo) ou para a esquerda (negativo)
							if (diffX > 0) {
								// Botão deslizado para a direita
								head.setTranslationX(diffX);
							} else {
								// Botão deslizado para a esquerda
								head.setTranslationX(0);
							}
							return true;
						case MotionEvent.ACTION_UP:
							// Verificar se o botão foi deslizado até a metade da largura
							if (Math.abs(head.getTranslationX()) >= head.getWidth() / 2) {
								// Botão deslizado até a metade ou mais da largura (considerado como "deslizado")
								// Lógica a ser executada quando o botão for deslizado, por exemplo, executar uma ação
								Toast.makeText(getApplicationContext(), "Inject Deslizado", Toast.LENGTH_SHORT).show();
								textView.setText(Html.fromHtml("</b><font color='#00F6500'><b>Inject</font></b><font color='#00FF00'> : <b>Online</font>"));
								arrow.setColorFilter(Color.parseColor("#00FF00"), PorterDuff.Mode.MULTIPLY);					
								handler = new Handler();
								runnable = new Runnable() {
									@Override
									public void run() {
										// Executa a verificação de ping
										new PingTask().execute();
										// Executa novamente o Runnable após 1 segundo (1000 ms)
										handler.postDelayed(this, 1000);
									}
								};
								// Inicia a atualização periódica do texto
								startUpdatingText();
								//inject();
							}
							// Restaurar a posição original do botão
							head.setTranslationX(0);
							return true;
					}
					return false;
				}
			});
		tab_inject.addView(head, -1, dp(39));
		tab_inject.addView(textView);
		tab_inject.addView(LOGS_ONO_OFF);
    }
	
	private void addAll(String buttonText, View.OnClickListener clickListener) {
		RelativeLayout titleText4 = new RelativeLayout(this);
        titleText4.setPadding(0, 5, 0, 5);
		TextView startximage = new TextView(this);
		//startximage.setText(Html.fromHtml("<font face=>" +buttonText+ "<font color='orange'> CMods<font>"));
		startximage.setText(Html.fromHtml("</b><font color='#00F6500'><b>" + buttonText + "</font></b><font color='#FFE69307'>CMods</font>"));
		startximage.setTextColor(Color.WHITE);
        startximage.setTextSize(22.0f);
		startximage.setGravity(Gravity.CENTER);
		startximage.setTypeface(null,Typeface.BOLD);
		startximage.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    closeMenu();
                }
            });
		RelativeLayout.LayoutParams rl00 = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl00.addRule(RelativeLayout.CENTER_HORIZONTAL);
        startximage.setLayoutParams(rl00);
		final LinearLayout ps = new LinearLayout(this);
		final ImageView Off_bad = new ImageView(this);
		Off_bad.setScaleType(ImageView.ScaleType.FIT_CENTER);
        setImageFromAssets(Off_bad,"back/inject.png",this);
		Off_bad.setLayoutParams(new LinearLayout.LayoutParams(dp(40),dp(33)));
		ps.addView(Off_bad);
		RelativeLayout.LayoutParams rl0 = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl0.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        ps.setLayoutParams(rl0);
		ps.setOnClickListener(clickListener);
	    menuLayout.addView(titleText4);
		titleText4.addView(startximage);
		titleText4.addView(ps);
    }
	
	private void addCheckBox(String text, CompoundButton.OnCheckedChangeListener listener) {
        LinearLayout SwitchLayout = new LinearLayout(this);
        LinearLayout.LayoutParams switchLayout = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);
        SwitchLayout.setLayoutParams(switchLayout);
        SwitchLayout.setOrientation(LinearLayout.HORIZONTAL);

        final GradientDrawable SwitchDrawable = new GradientDrawable();
        SwitchDrawable.setShape(GradientDrawable.OVAL);
        SwitchDrawable.setColor(Color.BLACK);
        SwitchDrawable.setStroke(dp(1), Color.WHITE);
        SwitchDrawable.setSize(dp(20), dp(20));

        final CheckBox FuncSwitch = new CheckBox(this);
        LinearLayout.LayoutParams funcSwitch = new LinearLayout.LayoutParams(MATCH_PARENT, dp(35));
        funcSwitch.leftMargin = dp(5);
        funcSwitch.rightMargin = dp(5);
        FuncSwitch.setLayoutParams(funcSwitch);
		FuncSwitch.setButtonTintList(ColorStateList.valueOf(Color.parseColor("#ffffff")));
        FuncSwitch.setText(text);
        FuncSwitch.setTextColor(Color.WHITE);
        FuncSwitch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        FuncSwitch.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View view) {
					if (FuncSwitch.isChecked()) {
						SwitchDrawable.setColor(Color.parseColor("#22AC22"));
					} else {
						SwitchDrawable.setColor(Color.BLACK);
					}
				}
			});
		FuncSwitch.setOnCheckedChangeListener(listener);
        caixadebotoes.addView(SwitchLayout);
        SwitchLayout.addView(FuncSwitch);
    }
	
	
	private void addCheckBox_fuc(String text, CompoundButton.OnCheckedChangeListener listener) {
        LinearLayout SwitchLayout2 = new LinearLayout(this);
        LinearLayout.LayoutParams switchLayout2 = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);
        SwitchLayout2.setLayoutParams(switchLayout2);
        SwitchLayout2.setOrientation(LinearLayout.HORIZONTAL);

        final GradientDrawable SwitchDrawable2 = new GradientDrawable();
        SwitchDrawable2.setShape(GradientDrawable.OVAL);
        SwitchDrawable2.setColor(Color.BLACK);
        SwitchDrawable2.setStroke(dp(1), Color.WHITE);
        SwitchDrawable2.setSize(dp(20), dp(20));

        final CheckBox FuncSwitch2 = new CheckBox(this);
        LinearLayout.LayoutParams funcSwitch2 = new LinearLayout.LayoutParams(MATCH_PARENT, dp(35));
        funcSwitch2.leftMargin = dp(5);
        funcSwitch2.rightMargin = dp(5);
        FuncSwitch2.setLayoutParams(funcSwitch2);
		FuncSwitch2.setButtonTintList(ColorStateList.valueOf(Color.parseColor("#ffffff")));
        FuncSwitch2.setText(text);
        FuncSwitch2.setTextColor(Color.WHITE);
        FuncSwitch2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        FuncSwitch2.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View view) {
					if (FuncSwitch2.isChecked()) {
						SwitchDrawable2.setColor(Color.parseColor("#22AC22"));
					} else {
						SwitchDrawable2.setColor(Color.BLACK);
					}
				}
			});
		FuncSwitch2.setOnCheckedChangeListener(listener);
        caixadebotoes3.addView(SwitchLayout2);
        SwitchLayout2.addView(FuncSwitch2);
    }
	private void Category(String text) {
		final TextView textView = new TextView(this);
		textView.setPadding(dp(3),dp(4),dp(3),dp(3));
		textView.setBackgroundColor(Color.parseColor("#000000"));
		textView.setText(Html.fromHtml(text));
		textView.setGravity(Gravity.CENTER);
		textView.setTextColor(Color.parseColor("#FFFFFF"));
		textView.setTypeface(null, Typeface.BOLD);
		caixadebotoes2.addView(textView);
	}
	private void logsView(String text) {
		final TextView textViewLOGS = new TextView(this);
		textViewLOGS.setPadding(dp(6),dp(4),dp(3),dp(3));
		textViewLOGS.setBackgroundColor(Color.parseColor("#000000"));
		textViewLOGS.setText(Html.fromHtml(text));
		textViewLOGS.setTextColor(Color.parseColor("#FFFFFF"));
		textViewLOGS.setTypeface(null, Typeface.BOLD);
		tab_inject.addView(textViewLOGS);
	}
	public WindowManager.LayoutParams setParams() {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(-1, -1);
        params.gravity = 16;
        params.flags = 8192;
        return params;
    }

    private void openMenu() {
        if (!isMenuOpen) {
            paramsMenu = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
				WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,//permi
                //WindowManager.LayoutParams.TYPE_APPLICATION,//no permi
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            );
            paramsMenu.gravity = Gravity.TOP | Gravity.START;
            paramsMenu.x = paramsIcon.x + floatingIcon.getWidth();
            paramsMenu.y = paramsIcon.y;
            windowManager.addView(menuLayout, paramsMenu);
			lineAi.lineWidth = 2.0f;//largura da linha
			lineAi.alpha = 255;//transparencia
            isMenuOpen = true;
        }
    }
	
    private void closeMenu() {
        if (isMenuOpen) {
			lineAi.lineWidth = 0;//largura da linha
			lineAi.alpha = 0;//transparencia
			windowManager.removeView(menuLayout);
            isMenuOpen = false;
        }
    }
	public final int dp(int i2) {
        return (int) TypedValue.applyDimension(1, (float) i2, this.getResources().getDisplayMetrics());
    }
    public void onDestroy() {
        if (floatingIcon != null) {
			stopUpdatingText();
            windowManager.removeView(floatingIcon);
        }
        if (menuLayout != null && isMenuOpen) {
			stopUpdatingText();
            windowManager.removeView(menuLayout);
        }
    }
	private class PingTask extends AsyncTask<Void, Void, String> {
		private String appendLogText;
		private String appendLogText2;
		private String appendLogText3;
		private String memoryInfo;
        @Override
        protected String doInBackground(Void... voids) {
			//String result;
            try {
                // Endereço IP ou nome do host para verificar o ping
                String ipAddress = "speedtest.net";//google.com";
                InetAddress inetAddress = InetAddress.getByName(ipAddress);

                // Define o tempo limite (timeout) para a resposta do ping em milissegundos
                int timeoutMs = 3000;
				
                // Verifica o ping
                long startTime = System.currentTimeMillis();
                boolean isReachable = inetAddress.isReachable(timeoutMs);
                long endTime = System.currentTimeMillis();
				
				//Verifica o host
				appendLogText = "Host: " + inetAddress.getHostAddress();
				appendLogText2 = "Nome Canônico: " + inetAddress.getCanonicalHostName();
				appendLogText3 = "Nome do Host: " + inetAddress.getHostName();
				// Obtém informações sobre a memória do dispositivo
				memoryInfo = getMemoryInfo();
				
                if (isReachable) {
                    long pingTime = endTime - startTime;
                    result = "Ping : " + pingTime + " ms";
                } else {
                    result = "Ping falhou";
                }
            } catch (IOException e) {
                result = "Erro: " + e.getMessage();
            }

            return result;
        }
        @Override
        protected void onPostExecute(String result) {
			logsView("</b><font color='#00F8F00'><b>" + "android device : "+ Build.MANUFACTURER + "</font>");
			logsView("</b><font color='#0c6eff'><b>" + "android device : "+ Build.PRODUCT + "</font>");
			logsView("</b><font color='#00F6500'><b>" + Build.TAGS + "</font></b><font color='#00FF00'> : <b>" + Build.SERIAL + "</font>");
			logsView("</b><font color='#00F6500'><b>Net</font></b><font color='#00FF00'> : <b>" + result + "</font>");
			logsView("</b><font color='#00F6500'><b>Host Info</font></b><font color='#00FF00'> : <b>" + appendLogText + "</font>");
			logsView("</b><font color='#00F6500'><b>Host Info</font></b><font color='#00FF00'> : <b>" + appendLogText2 + "</font>");
			logsView("</b><font color='#00F6500'><b>Host Info</font></b><font color='#00FF00'> : <b>" + appendLogText3 + "</font>");
			logsView("</b><font color='#00F6500'><b>MemoryInfo : </font></b><font color='red'><b>" + memoryInfo + "</font>");
			// Verifica se ocorreu um possível lag
			if (isLagDetected()) {// Exibe o Toast informando sobre o possível lag
				logsView("</b><font color='#00F6500'><b>lag</font></b><font color='red'> : <b>possível lag Detectado</font>");
			}
			// Obtenha o endereço IP do host
			//("https://www.speedtest.net");
			// Exiba informações do hos
		}
	}
	private void startUpdatingText() {
        // Executa o Runnable pela primeira vez após 1 segundo (1000 ms)
        handler.postDelayed(runnable, 1000);
    }
    private void stopUpdatingText() {
        // Interrompe a atualização periódica do texto
        handler.removeCallbacks(runnable);
    }
	private boolean isLagDetected() {
        // Aqui você pode adicionar a lógica para detectar um possível lag
        // Por exemplo, verificando o tempo de resposta de uma tarefa ou operação
        // Neste exemplo, estamos simulando um lag detectado a cada 5 segundos
        long currentTime = System.currentTimeMillis();
        return (currentTime % 5000) < 100; // A cada 5 segundos, durante os primeiros 100 ms
    }
	private String getMemoryInfo() {
		ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
		ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		if (activityManager != null) {
			activityManager.getMemoryInfo(memoryInfo);
			long totalMemory = memoryInfo.totalMem;
			long availableMemory = memoryInfo.availMem;
			boolean isLowMemory = memoryInfo.lowMemory;
			// Formata as informações em uma string
			String memoryInfoString = "Total Memory: " + formatMemorySize(totalMemory) + " | "+"\n"
				+ "Available Memory: " + formatMemorySize(availableMemory) + " | "+"\n"
				+ "Low Memory: " + isLowMemory;

			return memoryInfoString;
		} else {
			return "Unable to retrieve memory information";
		}
	}
	private String formatMemorySize(long bytes) {
		final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
		int index = 0;
		double value = bytes;
		while (value >= 1024 && index < units.length - 1) {
			value /= 1024;
			index++;
		}
		return String.format("%.2f %s", value, units[index]);
	}
}
