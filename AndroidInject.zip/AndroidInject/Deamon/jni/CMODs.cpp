#include "CMODs.h"
#include "CM/Offsets.h"

struct Feature {

    int WALLSTONE = 1;
    int NIGHTMODO = 2;
    
} Feature;



int main(int argc, char *argv[]){
    if (argv[1] != NULL && argv[2] != NULL){
        int Menu = atoi(argv[1]);
        int NoKey = atoi(argv[2]);
        if (Menu > 0 && Menu < 8){
        if (Mem.InitMemory()){
          if (Menu == Feature.WALLSTONE){
                    switch (NoKey) {//Wall Pedra v1.92 pegando
                        case 0:
                            Mem.Write(Mem.getRealOffset("libil2cpp.so",0xb63138), "-8388395.5", TYPE_FLOAT);
                            break;
                        case 1:
                            Mem.Write(Mem.getRealOffset("libil2cpp.so",0xb63128), "0.0", TYPE_FLOAT);
                            break;
                        }
                 }
                 if (Menu == Feature.NIGHTMODO){//v1.92 Modo Noite pegando
                    switch (NoKey) {
                        case 0:
                            Mem.Write(Mem.getRealOffset("libil2cpp.so",0x2ff8ac), "1.0e-6", TYPE_FLOAT);
                            break;
                        case 1:
                            Mem.Write(Mem.getRealOffset("libil2cpp.so",0x2ff8ac), "-1", TYPE_FLOAT);
                            break;
                     }
                }
				//add
            }
        }
    }
    return 0;
}
